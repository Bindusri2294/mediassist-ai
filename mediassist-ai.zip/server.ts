import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize GoogleGenAI client lazy-loaded or at startup with check
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    console.warn("Warning: GEMINI_API_KEY is not configured or uses a placeholder. Please configure it in your Secrets/Environment.");
  }
  return new GoogleGenAI({
    apiKey: apiKey || "",
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
};

app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ limit: '20mb', extended: true }));

// Express API endpoints
app.post("/api/analyze", async (req, res) => {
  try {
    const { reportText, fileBase64, fileType, language = "en" } = req.body;

    if (!reportText && (!fileBase64 || !fileType)) {
      return res.status(400).json({ error: "Please enter some report text, choose a sample, or upload a medical report image." });
    }

    const ai = getGeminiClient();

    // Setup input elements for Gemini
    const partsArray: any[] = [];

    if (fileBase64 && fileType) {
      // Add visual input for OCR and analysis
      partsArray.push({
        inlineData: {
          mimeType: fileType,
          data: fileBase64
        }
      });
    }

    // Prepare language prompt
    const langInstructions = language === "te"
      ? "You MUST return ALL text content, summaries, test purposes, explanations, meanings, findings, and general health tips in natural, layman-friendly TELUGU (తెలుగు) language. Keep Telugu terms clear, reassuring, and exceptionally polite, explaining standard medical terms simply."
      : "You MUST return all text, explanation details, summaries, definitions, terms, and guidelines in plain, beginner-friendly English.";

    const textPrompt = `You are MediAssist AI, an intelligent educational medical report explanation assistant.
Your absolute goals are:
1. Short Summary of the report stating the overall purpose of the test.
2. Identify and highlight key findings (Normal vs Results That May Need Attention).
3. Simple patient-friendly explanations for terms and findings (What it means, Why it matters, and Possible high/low reasons in simple language).
4. Generate 5-10 useful questions to ask their doctor.
5. Provide actionable, non-prescription health suggestions (Hydration, Nutrition, Exercise, Sleep, or Follow-up tests).

CRITICAL MEDICAL COMPLIANCE RULES:
- Do NOT diagnose any disease or clinical condition.
- Do NOT claim absolute certainty (use tentative, educational words like 'suggests', 'can indicate', 'under supervision of doctors').
- Always advise consulting a qualified clinician for authoritative medical decisions.
- Maintain an educational, objective, warm, and highly professional tone.

${langInstructions}

${reportText ? `Medical Report Content Provided as Text:\n${reportText}` : "Please read and analyze the uploaded medical report image."}`;

    partsArray.push({ text: textPrompt });

    // Define strict response schema matching our TypeScript/UI specs
    const responseSchema = {
      type: Type.OBJECT,
      properties: {
        reportSummary: {
          type: Type.STRING,
          description: "A patient-friendly, positive, and clear summary of what the report represents.",
        },
        testPurpose: {
          type: Type.STRING,
          description: "Simple explanation of the primary metric or biological reason this test is ordered.",
        },
        importantFindings: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              label: {
                type: Type.STRING,
                description: "Name of the component, molecule, or benchmark (e.g. Hemoglobin, LDL Cholesterol)"
              },
              value: {
                type: Type.STRING,
                description: "The patient's measured result (e.g. 10.8 g/dL)"
              },
              referenceRange: {
                type: Type.STRING,
                description: "The normal status span as benchmarked by labs (e.g. 12.0 - 15.5 g/dL)"
              },
              status: {
                type: Type.STRING,
                description: "Must be 'normal' if within range, or 'attention' if outside standard benchmarks."
              },
              explanation: {
                type: Type.OBJECT,
                properties: {
                  whatItMeans: {
                    type: Type.STRING,
                    description: "Layman breakdown of what this biomolecule or reading is."
                  },
                  whyItMatters: {
                    type: Type.STRING,
                    description: "Why the body needs this at a standard rate."
                  },
                  possibleReasons: {
                    type: Type.STRING,
                    description: "Tentative, non-diagnostic pathways that can alter this index (such as dietary intake, physical exercise, or sleep patterns)."
                  }
                },
                required: ["whatItMeans", "whyItMatters", "possibleReasons"]
              }
            },
            required: ["label", "value", "referenceRange", "status", "explanation"]
          }
        },
        simpleExplanations: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              term: {
                type: Type.STRING,
                description: "Complex clinical words (e.g. Microcytic, Hyperlipidemia, Subclinical)"
              },
              meaning: {
                type: Type.STRING,
                description: "A beautiful plain translation in simple sentences."
              }
            },
            required: ["term", "meaning"]
          }
        },
        questionsToAsk: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "Exactly 5 to 10 specific, practical questions targeting these findings that the user can ask their doctor."
        },
        generalHealthTips: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              category: {
                type: Type.STRING,
                description: "Specific categories: Hydration, Nutrition, Exercise, Sleep, or Follow-up"
              },
              tip: {
                type: Type.STRING,
                description: "A actionable, supportive lifestyle tip to discuss with a practitioner."
              }
            },
            required: ["category", "tip"]
          }
        }
      },
      required: [
        "reportSummary",
        "testPurpose",
        "importantFindings",
        "simpleExplanations",
        "questionsToAsk",
        "generalHealthTips"
      ]
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: partsArray },
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.1,
      }
    });

    const rawResponseText = response.text;
    if (!rawResponseText) {
      throw new Error("Empty response received from the educational AI agent.");
    }

    const cleanedText = rawResponseText.trim();
    const resultObj = JSON.parse(cleanedText);

    res.json(resultObj);
  } catch (error: any) {
    console.error("AI Analysis Error:", error);
    res.status(500).json({
      error: "Error processing the report. Please make sure the report content is legible.",
      details: error.message || error
    });
  }
});

// Setup Vite Dev Server / Static Hosting
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`MediAssist AI micro-backend listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
