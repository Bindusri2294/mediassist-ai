import React, { useState } from 'react';
import { MedicalReportAnalysis, ImportantFinding } from '../types';
import { 
  FileText, 
  Activity, 
  BookOpen, 
  UserCheck, 
  Heart, 
  AlertTriangle, 
  CheckCircle,
  HelpCircle,
  Droplet,
  Flame,
  Moon,
  TrendingDown,
  Printer,
  Copy,
  Check,
  Compass,
  Smile
} from 'lucide-react';

interface ReportDashboardProps {
  data: MedicalReportAnalysis;
  language: 'en' | 'te';
}

export default function ReportDashboard({ data, language }: ReportDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'findings' | 'glossary' | 'doctor' | 'tips'>('overview');
  const [selectedFinding, setSelectedFinding] = useState<ImportantFinding | null>(
    data.importantFindings && data.importantFindings.length > 0 ? data.importantFindings[0] : null
  );
  const [checkedQuestions, setCheckedQuestions] = useState<Record<number, boolean>>({});
  const [copied, setCopied] = useState(false);

  const attentionFindings = data.importantFindings.filter(f => f.status === 'attention');
  const normalFindings = data.importantFindings.filter(f => f.status === 'normal');

  // Trigger browser print
  const handlePrint = () => {
    window.print();
  };

  // Copy textual layout summary to clipboard
  const handleCopy = () => {
    try {
      const serializedText = `
MEDIASSIST AI - EDUCATIONAL EXPLANATION REPORT
======================================================
SUMMARY:
${data.reportSummary}

TEST PURPOSE:
${data.testPurpose}

IMPORTANT FINDINGS:
${data.importantFindings.map(f => `- ${f.label}: ${f.value} (${f.referenceRange}) [${f.status.toUpperCase()}]`).join('\n')}

TERMS EXPLAINED:
${data.simpleExplanations.map(s => `- ${s.term}: ${s.meaning}`).join('\n')}

QUESTIONS TO ASK FOR CLINIC:
${data.questionsToAsk.map((q, idx) => `${idx + 1}. ${q}`).join('\n')}

DISCLAIMER:
This explanation is for educational purposes only and is not a medical diagnosis. Please consult a qualified healthcare professional.
      `;
      navigator.clipboard.writeText(serializedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error(e);
    }
  };

  const toggleQuestion = (index: number) => {
    setCheckedQuestions(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  // Maps category labels to beautiful visuals/icons
  const getCategoryIcon = (category: string) => {
    const norm = category.toLowerCase();
    if (norm.includes('hydrat')) return <Droplet className="w-5 h-5 text-sky-500" />;
    if (norm.includes('nutri') || norm.includes('diet') || norm.includes('food')) return <Heart className="w-5 h-5 text-emerald-500 fill-emerald-500/10" />;
    if (norm.includes('exercis') || norm.includes('activ') || norm.includes('train')) return <Flame className="w-5 h-5 text-amber-500" />;
    if (norm.includes('sleep') || norm.includes('rest')) return <Moon className="w-5 h-5 text-indigo-500" />;
    return <Compass className="w-5 h-5 text-teal-500" />;
  };

  const getCategoryColorClass = (category: string) => {
    const norm = category.toLowerCase();
    if (norm.includes('hydrat')) return 'bg-sky-50 border-sky-100 text-sky-950';
    if (norm.includes('nutri')) return 'bg-emerald-50 border-emerald-100 text-emerald-950';
    if (norm.includes('exercis')) return 'bg-amber-50 border-amber-100 text-amber-950';
    if (norm.includes('sleep')) return 'bg-indigo-50 border-indigo-100 text-indigo-950';
    return 'bg-teal-50 border-teal-100 text-teal-950';
  };

  return (
    <div className="flex flex-col gap-5 print:p-0">
      
      {/* ACTION UTILITIES RIBBON */}
      <div className="flex justify-between items-center bg-slate-50 border border-slate-100 rounded-xl p-3 print:hidden">
        <span className="text-xs text-slate-500 font-medium">
          {language === 'en' ? 'Report Parsed Successfully' : 'నివేదిక విశ్లేషించబడింది'}
        </span>
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white border border-slate-200 hover:bg-slate-50 hover:text-slate-800 transition-all cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-teal-600" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? (language === 'en' ? 'Copied!' : 'కాపీ చేయబడింది!') : (language === 'en' ? 'Copy Summary' : 'కాపీ చేయి')}
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white border border-slate-200 hover:bg-slate-50 hover:text-slate-800 transition-all cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            {language === 'en' ? 'Print Guide' : 'ప్రింట్ తీసుకోండి'}
          </button>
        </div>
      </div>

      {/* DASHBOARD TAB DECK */}
      <div className="flex border-b border-slate-100 overflow-x-auto gap-1 sm:gap-2 no-scrollbar print:hidden">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-3 text-xs sm:text-sm font-semibold tracking-wide border-b-2 whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'overview'
              ? 'border-teal-600 text-teal-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          {language === 'en' ? 'Overview' : 'సారాంశం'}
        </button>
        <button
          onClick={() => setActiveTab('findings')}
          className={`px-4 py-3 text-xs sm:text-sm font-semibold tracking-wide border-b-2 whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'findings'
              ? 'border-teal-600 text-teal-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-200'
          }`}
        >
          <Activity className="w-4 h-4" />
          {language === 'en' ? 'Key Findings' : 'ముఖ్య సూచికలు'}
          {attentionFindings.length > 0 && (
            <span className="ml-1 bg-rose-100 text-rose-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
              {attentionFindings.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('glossary')}
          className={`px-4 py-3 text-xs sm:text-sm font-semibold tracking-wide border-b-2 whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'glossary'
              ? 'border-teal-600 text-teal-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-200'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          {language === 'en' ? 'Medical Terins' : 'పరిభాష'}
        </button>
        <button
          onClick={() => setActiveTab('doctor')}
          className={`px-4 py-3 text-xs sm:text-sm font-semibold tracking-wide border-b-2 whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'doctor'
              ? 'border-teal-600 text-teal-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-200'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          {language === 'en' ? 'Doctor Consult Guide' : 'వైద్యుల సంప్రదింపు సలహాలు'}
        </button>
        <button
          onClick={() => setActiveTab('tips')}
          className={`px-4 py-3 text-xs sm:text-sm font-semibold tracking-wide border-b-2 whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'tips'
              ? 'border-teal-600 text-teal-700 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-200'
          }`}
        >
          <Heart className="w-4 h-4" />
          {language === 'en' ? 'Health Tips' : 'ఆరోగ్య సూచనలు'}
        </button>
      </div>

      {/* RENDER ACTIVE TAB */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-5 sm:p-6 transition-all duration-300">
        
        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="flex flex-col gap-6 animate-fade-in">
            {/* Summary Block */}
            <div className="flex flex-col gap-2">
              <h3 className="font-display font-bold text-lg text-slate-900">
                {language === 'en' ? 'Medical Report Summary' : 'వైద్య నివేదిక సారాంశం'}
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                {data.reportSummary}
              </p>
            </div>

            {/* Overall test purpose explanation */}
            <div className="flex flex-col gap-2">
              <h4 className="font-sans font-bold text-sm text-slate-800 uppercase tracking-wider">
                {language === 'en' ? 'Primary Purpose of the Test' : 'ఈ పరీక్ష చేయడంలో ముఖ్య ఉద్దేశ్యం'}
              </h4>
              <p className="text-sm text-slate-600 leading-relaxed">
                {data.testPurpose}
              </p>
            </div>

            {/* High-Fidelity KPI Highlight Bento Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              
              <div className="border border-slate-100 rounded-xl p-4 bg-slate-50/30 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-sans font-medium uppercase tracking-wider text-slate-400">
                    {language === 'en' ? 'Total Biomarkers' : 'మొత్తం వైద్య కారకాలు'}
                  </span>
                  <p className="text-3xl font-display font-bold text-slate-900 mt-1">
                    {data.importantFindings.length}
                  </p>
                </div>
                <span className="text-xs text-slate-500 mt-2">
                  {language === 'en' ? 'Identified indices in report' : 'నివేదికలో నమోదైన మొత్తం కారకాలు'}
                </span>
              </div>

              <div className="border border-emerald-100 rounded-xl p-4 bg-emerald-50/10 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-sans font-medium uppercase tracking-wider text-emerald-600">
                      {language === 'en' ? 'Normal bounds' : 'సాధారణ ఆరోగ్య పరిధిలో'}
                    </span>
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                  </div>
                  <p className="text-3xl font-display font-bold text-emerald-950 mt-1">
                    {normalFindings.length}
                  </p>
                </div>
                <span className="text-xs text-emerald-700/80 mt-2">
                  {language === 'en' ? 'Consistent with optimal bounds' : 'శరీర వ్యవస్థ అనుకూలంగా ఉంది'}
                </span>
              </div>

              <div className={`border rounded-xl p-4 flex flex-col justify-between transition-colors ${
                attentionFindings.length > 0 
                  ? 'border-rose-100 bg-rose-50/10' 
                  : 'border-slate-100 bg-slate-50/30'
              }`}>
                <div>
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-sans font-medium uppercase tracking-wider ${
                      attentionFindings.length > 0 ? 'text-rose-600' : 'text-slate-400'
                    }`}>
                      {language === 'en' ? 'Needs Attention' : 'జాగ్రత్త వహించవలసినవి'}
                    </span>
                    <AlertTriangle className={`w-4 h-4 ${
                      attentionFindings.length > 0 ? 'text-rose-500 hover:animate-bounce' : 'text-slate-400'
                    }`} />
                  </div>
                  <p className={`text-3xl font-display font-bold mt-1 ${
                    attentionFindings.length > 0 ? 'text-rose-950' : 'text-slate-900'
                  }`}>
                    {attentionFindings.length}
                  </p>
                </div>
                <span className={`text-xs mt-2 ${
                  attentionFindings.length > 0 ? 'text-rose-700/80' : 'text-slate-500'
                }`}>
                  {attentionFindings.length > 0 
                    ? (language === 'en' ? 'Values to monitor with doctor' : 'మీ వైద్యుడితో సరిచూసుకోవచ్చు')
                    : (language === 'en' ? 'Optimal health parameters' : 'అన్నీ క్షేమంగా ఉన్నాయి')}
                </span>
              </div>

            </div>

            {/* Educational Disclaimer Section */}
            <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl">
              <h5 className="text-xs font-bold font-sans text-slate-800 uppercase tracking-wider mb-1.5">
                {language === 'en' ? 'Disclaimer' : 'ప్రకటన / వెల్లడి'}
              </h5>
              <p className="text-xs text-slate-500 leading-normal italic font-sans">
                "This explanation is for educational purposes only and is not a medical diagnosis. Please consult a qualified healthcare professional for medical advice."
              </p>
            </div>
          </div>
        )}

        {/* TAB 2: DETAILED FINDINGS */}
        {activeTab === 'findings' && (
          <div className="flex flex-col lg:flex-row gap-6 animate-fade-in">
            
            {/* L-SIDE: FINDINGS GRID/LIST */}
            <div className="flex-1 flex flex-col gap-3 max-h-[500px] overflow-y-auto pr-1">
              <h3 className="font-display font-bold text-lg text-slate-900 mb-2">
                {language === 'en' ? 'Analyzed Laboratory Markers' : 'విశ్లేషించబడిన ల్యాబ్ మార్కర్‌లు'}
              </h3>
              
              <div className="flex flex-col gap-2">
                {data.importantFindings.map((finding, idx) => {
                  const isAttention = finding.status === 'attention';
                  const isSelected = selectedFinding?.label === finding.label;
                  return (
                    <button
                      key={idx}
                      onClick={() => setSelectedFinding(finding)}
                      className={`text-left w-full p-4 rounded-xl border transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 ${
                        isSelected
                          ? 'border-teal-500 bg-teal-50/40 shadow-xs'
                          : isAttention
                            ? 'border-rose-100 bg-rose-50/10 hover:bg-rose-50/30'
                            : 'border-slate-100 bg-slate-50/20 hover:bg-slate-50/50'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-display font-bold text-sm text-slate-950">
                            {finding.label}
                          </span>
                          {isAttention && (
                            <span className="bg-rose-100 text-rose-700 text-[9px] font-bold px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                              {language === 'en' ? 'Attention' : 'జాగ్రత్త'}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-500 font-mono">
                          <span>
                            {language === 'en' ? 'Reference:' : 'సాధారణ పరిధి:'} <strong className="text-slate-700">{finding.referenceRange}</strong>
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 sm:self-center">
                        <span className={`px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold tracking-tight ${
                          isAttention 
                            ? 'bg-rose-50 text-rose-700 border border-rose-100' 
                            : 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                        }`}>
                          {finding.value}
                        </span>
                        <HelpCircle className={`w-4 h-4 hidden sm:block ${isSelected ? 'text-teal-600' : 'text-slate-300'}`} />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* R-SIDE: DETAILED EXPLANATION PANEL */}
            <div className="w-full lg:w-[450px] shrink-0 border border-slate-100 bg-slate-50/30 rounded-2xl p-5 sm:p-6 flex flex-col gap-5 justify-between">
              {selectedFinding ? (
                <div className="flex flex-col gap-4 animate-fade-in">
                  <div className="border-b border-slate-100 pb-3">
                    <span className={`inline-block text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md mb-2 ${
                      selectedFinding.status === 'attention' 
                        ? 'bg-rose-100 text-rose-800' 
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {selectedFinding.status === 'attention' 
                        ? (language === 'en' ? 'Requires Medical Core Review' : 'కీలక సమతుల్యత పరిశీలన')
                        : (language === 'en' ? 'Optimal Range Parameter' : 'సముచిత విలువ పరిధి')}
                    </span>
                    <h4 className="font-display font-bold text-base text-slate-900 leading-tight">
                      {selectedFinding.label} ({selectedFinding.value})
                    </h4>
                  </div>

                  {/* 1. What it is */}
                  <div className="flex flex-col gap-1.5">
                    <span className="text-xs font-bold text-teal-700 uppercase tracking-wider flex items-center gap-1">
                      <Compass className="w-3.5 h-3.5" />
                      {language === 'en' ? 'What it means' : 'దీని అర్థం ఏమిటి'}
                    </span>
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {selectedFinding.explanation.whatItMeans}
                    </p>
                  </div>

                  {/* 2. Why it matters */}
                  <div className="flex flex-col gap-1.5">
                    <span className="text-xs font-bold text-teal-700 uppercase tracking-wider flex items-center gap-1">
                      <Smile className="w-3.5 h-3.5" />
                      {language === 'en' ? 'Why it matters to your body' : 'శరీరానికి ఇది ఎందుకు ముఖ్యం'}
                    </span>
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {selectedFinding.explanation.whyItMatters}
                    </p>
                  </div>

                  {/* 3. Possible reasons */}
                  <div className="flex flex-col gap-1.5">
                    <span className="text-xs font-bold text-teal-700 uppercase tracking-wider flex items-center gap-1">
                      <TrendingDown className="w-3.5 h-3.5" />
                      {language === 'en' ? 'Possible reasons for deviation' : 'నివేదికలో మార్పులకు గల సాధారణ కారణాలు'}
                    </span>
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed italic bg-white p-3 rounded-xl border border-slate-100">
                      {selectedFinding.explanation.possibleReasons}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center text-center h-full py-12 text-slate-400 gap-3">
                  <Activity className="w-8 h-8 opacity-40 animate-pulse text-teal-600" />
                  <p className="text-sm">
                    {language === 'en' ? 'Select clinical index to check detailed patient-friendly explanation.' : 'మార్కర్ వివరాలపై క్లిక్ చేసి సమగ్ర విశ్లేషణ తెలుసుకోండి.'}
                  </p>
                </div>
              )}

              {/* Patient Reassurance Note */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-start gap-2 text-[11px] text-slate-400">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-slate-300" />
                <p>
                  {language === 'en'
                    ? 'Note: Fluctuations in biological benchmarks can spring from temporary context such as physical hydration rate, nutritional patterns, stress, or normal physiology.'
                    : 'గమనిక: శరీర జీవ రసాయన విలువలలో స్వల్ప వ్యత్యాసాలు తాత్కాలిక శారీరక మార్పులు, నీరు త్రాగే పరిమాణం, ఒత్తిడి లేదా నిద్ర ఆధారంగా ఉండవచ్చు.'}
                </p>
              </div>
            </div>

          </div>
        )}

        {/* TAB 3: MEDICAL TERMS GLOSSARY */}
        {activeTab === 'glossary' && (
          <div className="flex flex-col gap-4 animate-fade-in">
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900">
                {language === 'en' ? 'Medical Jargon Simply Translated' : 'వైద్య సాంకేతిక పదాల సరళీకృత వివరణ'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {language === 'en'
                  ? 'Fear not the latin terminologies. Here is a clear, simple interpretation of difficult laboratory words mentioned in your results.'
                  : 'క్లిష్టమైన వైద్యుడి చిట్కాలతో భయపడకండి. నివేదికలో ఉపయోగించిన ప్రతి సాంకేతిక పదం యొక్క సరళమైన విశ్లేషణ ఇక్కడ ఉంది.'}
              </p>
            </div>

            {data.simpleExplanations && data.simpleExplanations.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 mt-2">
                {data.simpleExplanations.map((item, idx) => (
                  <div key={idx} className="p-4 border border-slate-100 bg-slate-50/40 rounded-xl hover:border-teal-200 transition-colors flex flex-col gap-1.5">
                    <span className="font-display font-bold text-sm text-teal-900 border-b border-teal-50 ml-0 pb-1 self-start">
                      {item.term}
                    </span>
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mt-1">
                      {item.meaning}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center bg-slate-50 rounded-xl text-slate-400">
                {language === 'en' ? 'No complicated medical terms found to list.' : 'రిపోర్టులో సంక్లిష్టమైన వైద్యపదాలేమీ లభించలేదు.'}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: DOCTOR CONSULTATION PREPARATION CHECKLIST */}
        {activeTab === 'doctor' && (
          <div className="flex flex-col gap-5 animate-fade-in">
            <div className="border-b border-slate-100 pb-3">
              <h3 className="font-display font-bold text-lg text-slate-900 flex items-center gap-2">
                <Smile className="w-5 h-5 text-teal-600" />
                {language === 'en' ? 'Questions for Your Doctor' : 'మీ డాక్టర్‌ను అడగవలసిన ప్రశ్నలు'}
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed bg-teal-50/20 text-teal-950 p-2.5 rounded-lg border border-teal-100/50">
                {language === 'en'
                  ? 'Proactive preparation leads to safer health outcomes. Print or check off these curated questions to bring directly to your medical consultation clinic.'
                  : 'ముందుగా సిద్ధపడటం వలన ఆరోగ్య రక్షణ సులభతరం అవుతుంది. మీ వైద్యులతో సంప్రదింపుల్లో ఉపయోగించగల ముఖ్యమైన ప్రశ్నల జాబితా ఇక్కడ సిద్ధం చేయబడింది.'}
              </p>
            </div>

            {data.questionsToAsk && data.questionsToAsk.length > 0 ? (
              <div className="flex flex-col gap-2.5">
                {data.questionsToAsk.map((question, idx) => {
                  const isChecked = checkedQuestions[idx];
                  return (
                    <button
                      key={idx}
                      onClick={() => toggleQuestion(idx)}
                      className={`text-left w-full p-4 rounded-xl border flex items-start gap-3.5 transition-all cursor-pointer ${
                        isChecked
                          ? 'bg-slate-50 border-slate-200 text-slate-400'
                          : 'bg-white border-slate-100 hover:border-teal-200 text-slate-700'
                      }`}
                    >
                      <div className="mt-0.5">
                        {isChecked ? (
                          <div className="w-5 h-5 rounded-md bg-teal-600 text-white flex items-center justify-center animate-scale-up">
                            <Check className="w-3.5 h-3.5" />
                          </div>
                        ) : (
                          <div className="w-5 h-5 rounded-md border border-slate-300 hover:border-teal-500 bg-white" />
                        )}
                      </div>
                      <span className={`text-xs sm:text-sm leading-relaxed ${isChecked ? 'line-through text-slate-400 font-sans' : 'font-sans font-medium'}`}>
                        {question}
                      </span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center bg-slate-50 rounded-xl text-slate-400">
                {language === 'en' ? 'No automated clinic questions generated.' : 'ప్రశ్నల పట్టిక అందుబాటులో లేదు.'}
              </div>
            )}
          </div>
        )}

        {/* TAB 5: GENERAL HEALTH REPAIR PLAN */}
        {activeTab === 'tips' && (
          <div className="flex flex-col gap-4 animate-fade-in">
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900">
                {language === 'en' ? 'General Health recommendations' : 'సాధారణ ఆరోగ్య విధానాలు'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {language === 'en'
                  ? 'Practical, drug-free supportive guidelines surrounding sleep pattern, hydration rate, and dietary metrics.'
                  : 'ఒత్తిడి లేకుండా మరియు మందుల జోలికి వెళ్లకుండా మీ దినచర్యలో సులభంగా పాటించగల ఆరోగ్యకరమైన సూచనలు ఇక్కడ అందించబడ్డాయి.'}
              </p>
            </div>

            {data.generalHealthTips && data.generalHealthTips.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-2">
                {data.generalHealthTips.map((tip, idx) => (
                  <div 
                    key={idx} 
                    className={`border rounded-xl p-4 flex gap-3.5 items-start transition-transform hover:scale-[1.01] ${getCategoryColorClass(tip.category)}`}
                  >
                    <div className="p-2.0 bg-white rounded-lg shadow-xs mt-0.5">
                      {getCategoryIcon(tip.category)}
                    </div>
                    <div>
                      <span className="text-[10px] font-sans font-bold uppercase tracking-wider text-slate-500">
                        {tip.category}
                      </span>
                      <p className="text-xs sm:text-sm font-sans font-semibold mt-1 leading-relaxed">
                        {tip.tip}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center bg-slate-50 rounded-xl text-slate-400">
                {language === 'en' ? 'No health tips generated.' : 'సూచనలేమీ లభించలేదు.'}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
