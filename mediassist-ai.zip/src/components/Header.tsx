import { Heart, Activity, AlertCircle } from 'lucide-react';

interface HeaderProps {
  language: 'en' | 'te';
  setLanguage: (lang: 'en' | 'te') => void;
}

export default function Header({ language, setLanguage }: HeaderProps) {
  return (
    <header className="bg-white border-b border-slate-100 shadow-xs px-4 py-4 sm:px-6 relative z-10 transition-colors">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        
        {/* Brand details */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-12 h-12 rounded-xl bg-teal-50 text-teal-600 transition-transform duration-300 hover:scale-105">
            <Heart className="w-6 h-6 fill-teal-600/10" />
            <Activity className="absolute w-4 h-4 text-emerald-500 -bottom-1 -right-1 bg-white rounded-full p-0.5 shadow-xs" />
          </div>
          <div>
            <h1 className="font-display font-bold text-2xl tracking-tight text-slate-900 flex items-center gap-2">
              MediAssist AI
              <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-sans font-medium uppercase tracking-wider bg-emerald-50 text-emerald-700 rounded-md border border-emerald-100">
                Educational Desk
              </span>
            </h1>
            <p className="text-xs text-slate-500 font-sans mt-0.5">
              {language === 'en' 
                ? 'Your intelligent medical report explanation companion' 
                : 'మీ వైద్య పరీక్షల నివేదికను సులభంగా వివరించే సహాయక కేంద్రం'}
            </p>
          </div>
        </div>

        {/* Action controls (Language Switcher & Status indicator) */}
        <div className="flex items-center gap-3 self-end sm:self-center">
          <div className="bg-slate-100 p-1 rounded-xl flex items-center gap-1 border border-slate-200">
            <button
              onClick={() => setLanguage('en')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all ${
                language === 'en'
                  ? 'bg-white text-teal-700 shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200/50 hover:text-slate-900'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setLanguage('te')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all ${
                language === 'te'
                  ? 'bg-white text-teal-700 shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200/50 hover:text-slate-900'
              }`}
            >
              తెలుగు (Telugu)
            </button>
          </div>
        </div>

      </div>

      {/* Dynamic educational notice line */}
      <div className="max-w-7xl mx-auto mt-3">
        <div className="bg-amber-50/70 border border-amber-100 rounded-lg p-2.5 flex items-start gap-2.5 text-xs text-amber-800 font-medium">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <p>
            {language === 'en'
              ? 'Educational Resource Only: This system is powered by AI to help explain complex medical terms. It does not replace the expertise, review, or guidance of your personal healthcare provider.'
              : 'విద్యా ప్రయోజనాల కోసం మాత్రమే: వైద్య పరిభాషను సులభంగా అర్థం చేసుకోవడానికి మాత్రమే ఈ కృత్రిమ మేధస్సు సహాయపడుతుంది. ఇది వైద్యుల శారీరక పరీక్షకు ప్రత్యామ్నాయం కాదు.'}
          </p>
        </div>
      </div>
    </header>
  );
}
