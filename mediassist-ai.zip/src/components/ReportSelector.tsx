import React, { useRef, useState } from 'react';
import { SAMPLE_REPORTS } from '../samples';
import { SampleReport } from '../types';
import { FileText, UploadCloud, Link as LinkIcon, Sparkles, X, AlertCircle } from 'lucide-react';

interface ReportSelectorProps {
  language: 'en' | 'te';
  inputText: string;
  setInputText: (text: string) => void;
  fileBase64: string;
  setFileBase64: (base64: string) => void;
  fileType: string;
  setFileType: (type: string) => void;
  fileName: string;
  setFileName: (name: string) => void;
  onAnalyze: () => void;
  isLoading: boolean;
}

export default function ReportSelector({
  language,
  inputText,
  setInputText,
  fileBase64,
  setFileBase64,
  fileType,
  setFileType,
  fileName,
  setFileName,
  onAnalyze,
  isLoading
}: ReportSelectorProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  // Handle preset clicks
  const selectPreset = (report: SampleReport) => {
    setInputText(report.rawText);
    // Clear any file attachments to avoid confusing user
    setFileBase64('');
    setFileType('');
    setFileName('');
  };

  // Convert uploaded image file to Base64
  const handleUploadedFile = (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert(language === 'en' 
        ? 'Please upload an image file (PNG/JPG) of your medical report.' 
        : 'దయచేసి మీ మెడికల్ రిపోర్ట్ యొక్క పిఎన్‌జి లేదా జెపిజి ఇమేజ్‌ను మాత్రమే అప్‌లోడ్ చేయండి.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const b64 = reader.result as string;
      // b64 is formatted as: data:image/png;base64,...
      const actualBase64 = b64.split(',')[1];
      setFileBase64(actualBase64);
      setFileType(file.type);
      setFileName(file.name);
      
      // Focus user on the analyze view instead of copy-paste input
      setInputText('');
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleUploadedFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleUploadedFile(e.dataTransfer.files[0]);
    }
  };

  const clearFile = () => {
    setFileBase64('');
    setFileType('');
    setFileName('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-xs p-5 sm:p-6 flex flex-col gap-6">
      
      {/* 1. PRESET SAMPLES */}
      <div>
        <h2 className="text-sm font-semibold text-slate-800 uppercase tracking-wider font-sans mb-3 flex items-center gap-1.5">
          <FileText className="w-4 h-4 text-teal-600" />
          {language === 'en' ? 'Select Sample Report' : 'నమూనా నివేదికను ఎంచుకోండి'}
        </h2>
        <p className="text-xs text-slate-500 mb-3">
          {language === 'en'
            ? 'Don’t have a medical report on hand? Select one of our realistic lab reports to test how the explainer highlights subclinical findings.'
            : 'మీ వద్ద ప్రస్తుతం వైద్య నివేదిక లేదా? వివిద రుగ్మతల నమూనాలను ఇక్కడే ఒకే క్లిక్‌తో పరిశీలించండి.'}
        </p>
        <div className="grid grid-cols-1 gap-2.5">
          {SAMPLE_REPORTS.map((report) => (
            <button
              key={report.id}
              onClick={() => selectPreset(report)}
              className="group text-left p-3.5 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-teal-50/40 hover:border-teal-200 transition-all flex flex-col gap-1 cursor-pointer"
            >
              <div className="flex items-center justify-between w-full">
                <span className="font-display font-bold text-sm text-slate-800 group-hover:text-teal-900">
                  {report.title}
                </span>
                <span className="text-[10px] bg-slate-100 group-hover:bg-teal-100 text-slate-600 group-hover:text-teal-800 px-2 py-0.5 rounded-md font-sans font-medium transition-all">
                  {language === 'en' ? 'Quick Test' : 'వెంటనే పరీక్షించు'}
                </span>
              </div>
              <span className="text-xs text-slate-500 line-clamp-1">
                {report.description}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* HORIZONTAL SPLITTER OR LABEL */}
      <div className="relative flex py-2 items-center">
        <div className="flex-grow border-t border-slate-100"></div>
        <span className="flex-shrink mx-3 text-slate-400 font-display font-medium text-xs tracking-wider uppercase">
          {language === 'en' ? 'OR' : 'లేదా'}
        </span>
        <div className="flex-grow border-t border-slate-100"></div>
      </div>

      {/* 2. IMAGE UPLOAD ZONE */}
      <div>
        <h2 className="text-sm font-semibold text-slate-800 uppercase tracking-wider font-sans mb-3 flex items-center gap-1.5">
          <UploadCloud className="w-4 h-4 text-teal-600" />
          {language === 'en' ? 'Upload Image / Scan' : 'రిపోర్ట్ ఫోటో లేదా స్కాన్ అప్‌లోడ్'}
        </h2>
        
        {fileName ? (
          <div className="border border-teal-100 bg-teal-50/20 rounded-xl p-4 flex items-center justify-between gap-3 animate-fade-in">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="p-2.5 bg-teal-50 text-teal-600 rounded-lg">
                <FileText className="w-5 h-5" />
              </div>
              <div className="overflow-hidden">
                <p className="text-sm font-semibold text-teal-950 truncate">{fileName}</p>
                <p className="text-xs text-teal-700/80">{language === 'en' ? 'Image uploaded' : 'చిత్రం అప్‌లోడ్ చేయబడింది'}</p>
              </div>
            </div>
            <button
              onClick={clearFile}
              className="p-1 px-2 text-xs font-semibold text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1 transition-all cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              {language === 'en' ? 'Remove' : 'తొలగించు'}
            </button>
          </div>
        ) : (
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-7 text-center flex flex-col items-center justify-center gap-2 cursor-pointer transition-all ${
              isDragOver
                ? 'border-teal-500 bg-teal-50/30'
                : 'border-slate-200 hover:border-teal-400 hover:bg-slate-50/50'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
            <div className="p-3 bg-teal-50 rounded-full text-teal-600">
              <UploadCloud className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-800">
                {language === 'en' ? 'Click to upload or drag & drop' : 'క్లిక్ చేయండి లేదా ఇక్కడ డ్రాగ్ చేయండి'}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                {language === 'en' ? 'Supports JPG, PNG (Max 10MB)' : 'కేవలం ఇమేజ్ (JPG, PNG) ఫార్మాట్లు మాత్రమే'}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 3. TEXT AREA INPUT FOR COPY-PASTE */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-semibold text-slate-800 uppercase tracking-wider font-sans flex items-center gap-1.5">
            <LinkIcon className="w-3.5 h-3.5 text-teal-600" />
            {language === 'en' ? 'Paste Report Text Contents' : 'నివేదిక యొక్క టెక్స్ట్ ఇక్కడ పేస్ట్ చేయండి'}
          </label>
          {inputText && (
            <button
              onClick={() => setInputText('')}
              className="text-[10px] font-medium text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              {language === 'en' ? 'Clear Content' : 'టెక్స్ట్ తొలగించు'}
            </button>
          )}
        </div>
        <textarea
          value={inputText}
          onChange={(e) => {
            setInputText(e.target.value);
            if (e.target.value) {
              clearFile(); // prioritize text when typing custom
            }
          }}
          placeholder={
            language === 'en'
              ? 'Paste the full medical lab text here (e.g., RBC 4.2 L, Hemoglobin 10.5 L, etc.)...'
              : 'మెడికల్ రిపోర్ట్‌లోని వివరాలను ఇక్కడ రాయండి లేదా పేస్ట్ చేయండి...'
          }
          rows={6}
          className="w-full text-sm font-mono p-4 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-teal-500/10 focus:border-teal-500 bg-slate-50/30 transition-all resize-none"
        />
      </div>

      {/* TRIGGER EXPLAIN BUTTON */}
      <button
        onClick={onAnalyze}
        disabled={isLoading || (!inputText.trim() && !fileBase64)}
        className={`w-full py-4 px-6 rounded-xl font-display font-bold text-sm tracking-wide shadow-sm flex items-center justify-center gap-2.5 transition-all text-white ${
          isLoading || (!inputText.trim() && !fileBase64)
            ? 'bg-slate-200 border border-slate-300 text-slate-500 cursor-not-allowed'
            : 'bg-teal-600 hover:bg-teal-700 active:scale-[0.99] cursor-pointer'
        }`}
      >
        <Sparkles className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
        {isLoading 
          ? (language === 'en' ? 'Analyzing Medical Indices...' : 'వైద్య సూచికలను విశ్లేషిస్తోంది...')
          : (language === 'en' ? 'Explain My Report' : 'నా రిపోర్ట్‌ను వివరించు')}
      </button>

    </div>
  );
}
