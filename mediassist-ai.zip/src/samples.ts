import { SampleReport } from './types';

export const SAMPLE_REPORTS: SampleReport[] = [
  {
    id: 'cbc-anemia',
    title: 'Complete Blood Count (CBC)',
    description: 'A standard blood test showing signs of borderline anemia (low hemoglobin and iron indicators).',
    rawText: `LABORATORY REPORT - METROPOLIS HEALTHCARE
PATIENT: Jane Doe  |  AGE: 34  |  GENDER: Female  |  DATE: June 02, 2026

TEST DESCRIPTION               RESULT      REFERENCE RANGE      UNIT
---------------------------------------------------------------------
White Blood Cells (WBC)         6.2         4.5 - 11.0          x10^3/uL
Red Blood Cells (RBC)           3.8 L       4.0 - 5.2           x10^6/uL
Hemoglobin                      10.8 L       12.0 - 15.5         g/dL
Hematocrit                      32.5 L      37.0 - 48.0         %
Mean Corpuscular Volume (MCV)   76.0 L      80.0 - 100.0        fL
Platelets                       245         150 - 450           x10^3/uL
Serum Iron                      42 L        50 - 170            mcg/dL
Ferritin                        12 L        15 - 150            ng/mL

Memo: Mild microcytic hypochromic red cell indices. Suggestive of early iron deficiency.`
  },
  {
    id: 'thyroid-elevated',
    title: 'Thyroid Care Panel',
    description: 'A hormonal profile indicating a mildly overactive thyroid system indicator (underactive thyroid gland).',
    rawText: `GLOBAL DIAGNOSTIC LABS - ENDOCRINE PANEL
PATIENT: Robert Smith  |  AGE: 48  |  GENDER: Male  |  DATE: May 28, 2026

TEST DESCRIPTION               RESULT      REFERENCE RANGE      UNIT
---------------------------------------------------------------------
Triiodothyronine (T3, Free)     2.8         2.0 - 4.4           pg/mL
Thyroxine (T4, Free)            0.9         0.8 - 1.8           ng/dL
Thyroid Stimulating Hormone     5.8 H       0.4 - 4.0           mIU/L

Memo: Serum TSH is mildly elevated with normal free T4. This pattern is characteristic of subclinical hypothyroidism. Patient should correlate with clinical symptomatology.`
  },
  {
    id: 'lipid-cholesterol',
    title: 'Lipid (Cholesterol) Profile',
    description: 'Standard cardiovascular health screening demonstrating elevated bad cholesterol and triglyceride parameters.',
    rawText: `HEART & VASCULAR CLINICAL REPORT
PATIENT: Alice Green  |  AGE: 55  |  GENDER: Female  |  DATE: June 01, 2026

TEST DESCRIPTION               RESULT      REFERENCE RANGE      UNIT
---------------------------------------------------------------------
Total Cholesterol               245 H       < 200               mg/dL
Triglycerides                   185 H       < 150               mg/dL
HDL ("Good" Cholesterol)        42 L        > 50                mg/dL
LDL ("Bad" Cholesterol)         166 H       < 100               mg/dL

Memo: Mixed hyperlipidemia. Heart-healthy lifestyle modification recommended. Clinical follow-up suggested.`
  }
];
