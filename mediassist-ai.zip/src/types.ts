export interface ImportantFinding {
  label: string;
  value: string;
  referenceRange: string;
  status: 'normal' | 'attention';
  explanation: {
    whatItMeans: string;
    whyItMatters: string;
    possibleReasons: string;
  };
}

export interface SimpleExplanation {
  term: string;
  meaning: string;
}

export interface HealthRecommendation {
  category: 'Hydration' | 'Nutrition' | 'Exercise' | 'Sleep' | 'Follow-up' | string;
  tip: string;
}

export interface MedicalReportAnalysis {
  reportSummary: string;
  testPurpose: string;
  importantFindings: ImportantFinding[];
  simpleExplanations: SimpleExplanation[];
  questionsToAsk: string[];
  generalHealthTips: HealthRecommendation[];
}

export interface SampleReport {
  id: string;
  title: string;
  description: string;
  rawText: string;
}
