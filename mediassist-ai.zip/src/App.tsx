import { useState, useEffect } from 'react';
import Header from './components/Header';
import ReportSelector from './components/ReportSelector';
import ReportDashboard from './components/ReportDashboard';
import { MedicalReportAnalysis } from './types';
import { 
  Heart, 
  ShieldCheck, 
  Stethoscope, 
  Sparkles, 
  AlertCircle,
  HelpCircle,
  FileText
} from 'lucide-react';

export default function App() {
  const [language, setLanguage] = useState<'en' | 'te'>('en');
  const [inputText, setInputText] = useState<string>('');
  const [fileBase64, setFileBase64] = useState<string>('');
  const [fileType, setFileType] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingPhase, setLoadingPhase] = useState<number>(0);
  const [analysisResult, setAnalysisResult] = useState<MedicalReportAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Rotate loading text phases when active to reassure user in simple language
  useEffect(() => {
    let timer: any;
    if (isLoading) {
      setLoadingPhase(0);
      timer = setInterval(() => {
        setLoadingPhase((p) => (p + 1) % 5);
      }, 2200);
    } else {
      setLoadingPhase(0);
    }
    return () => clearInterval(timer);
  }, [isLoading]);

  const getLoadingMessage = () => {
    switch (loadingPhase) {
      case 0:
        return language === 'en' 
          ? 'Scanning medical text and optical parameters...' 
          : 'వైద్య నివేదిక సూచీలను స్కాన్ చేస్తోంది...';
      case 1:
        return language === 'en' 
          ? 'Evaluating bio-markers against normal clinical ranges...' 
          : 'సాధారణ పరిధుల ఆధారంగా విలువలను సరిచూస్తోంది...';
      case 2:
        return language === 'en' 
          ? 'Simplifying complex clinical terminology & jargon...' 
          : 'సంక్లిష్టమైన వైద్య పదాలను సరళీకరిస్తోంది...';
      case 3:
        return language === 'en' 
          ? 'Synthesizing tailored questions for your physician...' 
          : 'మీ వైద్యుడిని అడగవలసిన ప్రశ్నలను సిద్ధం చేస్తోంది...';
      case 4:
        return language === 'en' 
          ? 'Drafting general healthy hydration and nutrition recommendations...' 
          : 'ఆరోగ్య సంరక్షణ మరియు జీవనశైలి సలహాలను క్రోడీకరిస్తోంది...';
      default:
        return language === 'en' ? 'Formulating translation guides...' : 'వివరణలను సిద్ధం చేస్తోంది...';
    }
  };

  const handleAnalyze = async () => {
    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          reportText: inputText,
          fileBase64,
          fileType,
          language
        }),
      });

      if (!response.ok) {
        const errDetail = await response.json();
        throw new Error(errDetail.error || 'Server error during parsing.');
      }

      const parsedData = await response.json();
      setAnalysisResult(parsedData);
    } catch (err: any) {
      console.error(err);
      setError(
        err.message || 
        (language === 'en' 
          ? 'An error occurred while generating the explanation. Please try copying report text directly.' 
          : 'నివేదిక విశ్లేషణలో లోపం సంభవించింది. దయచేసి వివరాలను సరిచూసుకోండి.')
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-800 selection:bg-teal-100 selection:text-teal-900">
      
      {/* BRAND & USER LANG BANNER */}
      <Header language={language} setLanguage={setLanguage} />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col lg:flex-row gap-6 items-start relative z-0">
        
        {/* LEFT COLUMN: CONTROLS & SELECTION */}
        <div className="w-full lg:w-[380px] shrink-0 flex flex-col gap-5 print:hidden">
          <ReportSelector
            language={language}
            inputText={inputText}
            setInputText={setInputText}
            fileBase64={fileBase64}
            setFileBase64={setFileBase64}
            fileType={fileType}
            setFileType={setFileType}
            fileName={fileName}
            setFileName={setFileName}
            onAnalyze={handleAnalyze}
            isLoading={isLoading}
          />

          {/* Quick FAQ info Card */}
          <div className="bg-white rounded-2xl border border-slate-100 p-5 flex flex-col gap-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 font-sans">
              <Stethoscope className="w-3.5 h-3.5 text-teal-600" />
              {language === 'en' ? 'How it works' : 'ఇది ఎలా పనిచేస్తుంది?'}
            </h3>
            <ul className="text-xs text-slate-500 flex flex-col gap-2 leading-relaxed">
              <li className="flex gap-2">
                <span className="text-teal-600 font-bold font-sans">1.</span>
                <span>
                  {language === 'en'
                    ? 'Upload a photo/scan or paste raw laboratory text metrics.'
                    : 'పరీక్ష వివరాలను పేస్ట్ చేయండి లేదా నివేదిక ఫోటో అప్‌లోడ్ చేయండి.'}
                </span>
              </li>
              <li className="flex gap-2">
                <span className="text-teal-600 font-bold font-sans">2.</span>
                <span>
                  {language === 'en'
                    ? 'Confirm or switch translation settings (English or Telugu).'
                    : 'మీకు కావలసిన భాషను (తెలుగు లేదా ఇంగ్లీష్) ఎంచుకోండి.'}
                </span>
              </li>
              <li className="flex gap-2">
                <span className="text-teal-600 font-bold font-sans">3.</span>
                <span>
                  {language === 'en'
                    ? 'Read patient-friendly explanations, key anomalies highlighted, and customized consult questions.'
                    : 'సరళమైన పదాలలో వివరణలు మరియు డాక్టర్‌ని అడగవలసిన ప్రశ్నల జాబితాను పొందండి.'}
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* RIGHT COLUMN: RESULTS PORTLET */}
        <div className="flex-1 w-full min-h-[400px]">
          
          {/* 1. LOADING SCREEN & SKELETON GAUGE */}
          {isLoading && (
            <div className="bg-white rounded-2xl border border-slate-100 p-8 sm:p-12 text-center flex flex-col items-center justify-center gap-6 h-full min-h-[460px] animate-fade-in">
              <div className="relative flex items-center justify-center w-20 h-20">
                {/* Dual spinning circles matching professional clinical theme */}
                <div className="absolute w-full h-full border-4 border-slate-100 rounded-full"></div>
                <div className="absolute w-full h-full border-4 border-teal-600 border-t-transparent rounded-full animate-spin"></div>
                <Heart className="w-8 h-8 text-teal-600 animate-pulse" />
              </div>
              <div className="max-w-md">
                <p className="font-display font-medium text-slate-400 text-xs tracking-widest uppercase">
                  {language === 'en' ? 'MediAssist Process' : 'విశ్లేషణ ప్రక్రియ'}
                </p>
                <h3 className="font-display font-bold text-lg text-slate-800 mt-2 min-h-[48px] px-4">
                  {getLoadingMessage()}
                </h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  {language === 'en'
                    ? 'Kindly wait while we inspect reference bounds. This can take approximately 5 to 10 seconds depending on report length.'
                    : 'వైద్య విలువల నిశిత పరిశీలనకు దయచేసి కొన్ని క్షణాలు వేచి ఉండండి.'}
                </p>
              </div>

              {/* Simulated Skeleton Lines */}
              <div className="w-full max-w-sm flex flex-col gap-2.5 mt-2 opacity-50">
                <div className="h-4 bg-slate-100 rounded-full w-3/4 mx-auto animate-pulse"></div>
                <div className="h-3 bg-slate-50 rounded-full w-1/2 mx-auto animate-pulse"></div>
              </div>
            </div>
          )}

          {/* 2. ERROR DISPLAY */}
          {error && !isLoading && (
            <div className="bg-white rounded-2xl border border-rose-100 p-6 flex flex-col items-center justify-center text-center gap-4 min-h-[400px] animate-fade-in">
              <div className="w-14 h-14 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div>
                <h3 className="font-display font-bold text-lg text-slate-800">
                  {language === 'en' ? 'Parsing Attempt Unsuccessful' : 'విశ్లేషణ సాధ్యం కాలేదు'}
                </h3>
                <p className="text-sm text-slate-500 mt-1.5 max-w-md leading-relaxed">
                  {error}
                </p>
              </div>
              <button
                onClick={handleAnalyze}
                className="px-5 py-2.5 rounded-xl bg-teal-600 text-white font-display font-bold text-xs hover:bg-teal-700 transition-all cursor-pointer"
              >
                {language === 'en' ? 'Retry Parse Process' : 'మళ్ళీ ప్రయతించు'}
              </button>
            </div>
          )}

          {/* 3. READY DISPLAY DASHBOARD */}
          {analysisResult && !isLoading && !error && (
            <ReportDashboard data={analysisResult} language={language} />
          )}

          {/* 4. INTRO PLACEHOLDER SCREEN */}
          {!analysisResult && !isLoading && !error && (
            <div className="bg-white rounded-2xl border border-slate-100 p-8 sm:p-12 text-center flex flex-col items-center justify-center gap-5 h-full min-h-[500px]">
              
              <div className="relative flex items-center justify-center w-16 h-16 bg-teal-50 rounded-2xl text-teal-600">
                <Stethoscope className="w-8 h-8" />
                <Sparkles className="absolute -top-1 -right-1 w-4.5 h-4.5 text-emerald-500 bg-white rounded-full p-0.5 shadow-xs" />
              </div>

              <div className="max-w-md">
                <h3 className="font-display font-bold text-xl text-slate-900 tracking-tight">
                  {language === 'en' ? 'Awaiting Medical Data Inputs' : 'వైద్య వివరాల కోసం ఎదురుచూస్తోంది'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 mt-2 leading-relaxed">
                  {language === 'en'
                    ? 'Select a high-quality sample report pattern from the selector pane, paste laboratory diagnostic parameters directly, or upload a scanned image to synthesize explanations instantly.'
                    : 'ఎడమ వైపు ప్యానెల్ నుండి నమూనాను ఎంచుకోండి లేదా మీ రిపోర్ట్ చిత్రం అప్‌లోడ్ చేసి వివరాలు సులభంగా అర్థం చేసుకోండి.'}
                </p>
              </div>

              {/* Trust Badge items */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md w-full mt-5">
                <div className="p-3.5 rounded-xl bg-slate-50/50 border border-slate-100 flex items-center gap-2.5 text-left">
                  <ShieldCheck className="w-5 h-5 text-teal-600 shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-slate-800">
                      {language === 'en' ? 'Educational Security' : 'విద్యా సంరక్షణ'}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {language === 'en' ? 'No automated diagnostic claims' : 'ఎలాంటి తప్పుడు క్లెయిమ్‌లు చేయబడవు'}
                    </p>
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50/50 border border-slate-100 flex items-center gap-2.5 text-left">
                  <FileText className="w-5 h-5 text-teal-600 shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-slate-800">
                      {language === 'en' ? 'Telugu Translation' : 'తెలుగు భాషా మద్దతు'}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {language === 'en' ? 'Comprehensive simple Telugu text' : 'పదాలు సులభంగా అనువదించబడతాయి'}
                    </p>
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-slate-100 py-6 px-4 mt-12 print:hidden">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <p className="text-xs text-slate-400">
            &copy; 2026 MediAssist AI. {language === 'en' ? 'All educational summaries formatted using Gemini.' : 'అన్ని వివరాలు జెమిని టెక్నాలజీస్ ద్వారా విశ్లేషింపబడ్డాయి.'}
          </p>
          <div className="flex items-center gap-3 text-xs font-sans text-slate-400 font-medium">
            <span>{language === 'en' ? 'Non-Clinical Advisor' : 'సలహా ప్రయోజనాల కొరకు'}</span>
            <span>&bull;</span>
            <span>{language === 'en' ? 'Patient Empowerment Desk' : 'ఆరోగ్య చైతన్య వేదిక'}</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
